export type Role = 'admin' | 'standard-user';
