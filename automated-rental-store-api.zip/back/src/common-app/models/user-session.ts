import { Role } from './role';

export interface UserSession {
  id: string;
  role: Role;
}
